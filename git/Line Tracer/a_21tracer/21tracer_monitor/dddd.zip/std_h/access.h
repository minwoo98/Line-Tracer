/* access.h: Empty by default */
