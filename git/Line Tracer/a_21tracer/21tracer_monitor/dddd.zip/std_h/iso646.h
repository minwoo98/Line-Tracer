/*****************************************************************************/
/* ISO646.H v4.1.0                                                           */
/* Copyright (c) 2000-2005 Texas Instruments Incorporated                    */
/*****************************************************************************/
#define and    &&
#define and_eq &=
#define bitand &
#define bitor  |
#define compl  ~
#define not    !
#define not_eq !=
#define or     ||
#define or_eq  |=
#define xor    ^
#define xor_eq ^=
